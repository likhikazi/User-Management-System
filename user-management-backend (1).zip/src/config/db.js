module.exports = () => {
  console.log("Database connected (dummy)");
};
