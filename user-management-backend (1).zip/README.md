User Management Backend - Express JS

Run Project:
1. npm install
2. npm run dev
3. Open Browser/Postman:
   http://localhost:5000/api/users/create-user
