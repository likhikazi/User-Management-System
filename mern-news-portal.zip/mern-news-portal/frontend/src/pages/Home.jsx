
const Home = () => {
  return (
    <div>
      <h1>MERN News Portal</h1>
      <p>Top 6 news section here</p>
    </div>
  );
};

export default Home;
