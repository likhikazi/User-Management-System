
const mongoose = require("mongoose");

const newsSchema = new mongoose.Schema({
  title: String,
  description: String,
  image: String,
  category: String
});

module.exports = mongoose.model("News", newsSchema);
