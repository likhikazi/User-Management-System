
# MERN News Portal Assignment

Features:
- Home Page
- News Page
- News Details
- Login/Register
- Dashboard
- Create/Edit/Delete News
- Contact Page

Tech:
- React JS
- Tailwind CSS
- Node JS
- Express JS
- MongoDB
